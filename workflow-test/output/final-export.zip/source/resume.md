# My Resume

## Experience
- Software Engineer at TechCorp
- Built amazing tools

## Skills
- JavaScript, Python, Go
